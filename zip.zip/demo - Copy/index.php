<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <nav style="background-image: url(header-bg.svg); height: 200px;">
    <label>
        <img src="22A4FAD0618CD94051548BD71DDB41A2.png" style="height: 75px;">
    </label>
    <ul>
        <li><a href="#"><i class="fa-solid fa-house" style="color: #2ca039;"></i>Home</a></li>
        <li><a href="#"><i class="fa-solid fa-calculator" style="color: #299e46;"></i>Calculator</a></li>
        <li><a href="#"><i class="fa-solid fa-hand-holding-dollar" style="color: #44834e;"></i>Services</a></li>
        <li><a href="#"><i class="fa-solid fa-blog" style="color: #35b14e;"></i>Blog</a></li>
        <li><a href="#"><i class="fa-regular fa-comment" style="color: #35924c;"></i>Reviews</a></li>
        <button type="button" class="btn btn-primary">Contact</button>
</ul>
</nav>
<div>
    <img src="banner.svg" style="height: 300px; margin-left: 10%; float: left;">
    <button type="button" class="btn btn-success" style="margin-left: 7%;">Loan EMI calculator</button>
     <div class="loan"><h1 style="font-weight: bold;">A personal loan for <br>multiple purposes!</h1>
        <h4>Don't let financial constraints hold you back.<br> Take the first step towards your dreams by<br> applying for a personal loan today. Our<br> user-friendly online application process<br> makes it convenient for you to get <br>the funds you need, when you <br> need them.</h4>
        <br>
        <button class="button button3" style="background-color: rgb(80, 173, 205);border-radius: 15px;">Learn more</button>
     </div>
</div>
<div id="Services">
    <h1> Our Services</h1>
    <i class="fa-solid fa-bars-progress" style="color: #357e47;" id="pro"></i>
    <h4 class="hhh">Personal Loans: Flexible funding for dreams.<br>
        Education Loans: Invest in your future.<br>
        Home Loans: Step into your dream home.<br>
        Auto Loans: Drive your dream car.<br>
        Small Business Loans: Boost your business.<br>
        Emergency Loans: Quick financial help.<br>
        </h4>
        
        <!-- <div class="homeloan">
            <img src="001-credit.png" id="loanimage"><br>
            <button class="button button3" style="margin-left: 85px;margin-top: 20px;cursor: pointer;" >Home Loan</button>
            <p style="margin-left: 20px;margin-top: 10px;">"Own your dream home with our competitive Home Loans. Flexible terms, low rates, hassle-free process."</p>
            <div class="carloan">
                <img src="002-automobile.png" id="carimg">
                <button class="button button3" style="margin-left: 85px;margin-top: 20px;cursor: pointer;" >Car Loan</button>
                <p style="margin-left: 20px;margin-top: 10px;" >"Drive your dream car with our affordable Car Loans. Quick approvals, low rates, hassle-free process."</p>
            </div>
            <div class="perloan">
                <img src="003-profits.png" id="perimg">
                <button class="button button3" style="margin-left: 70px;margin-top: 20px;cursor: pointer;" >Perloan Loan</button>
                <p style="margin-left: 20px;">"Realize your dreams with our Personal Loans. Fast approvals, flexible terms, and reliable support."</p>
            </div>
</div> -->
<div class="container">
    <div class="homeloan">
        <img src="001-credit.png" id="loanimage"><br>
            <button class="button button3" style="margin-left: 60px;margin-top: 20px;cursor: pointer;" >Home Loan</button>
            <p style="margin-left: 20px;margin-top: 10px;">"Own your dream home with our competitive Home Loans. Flexible terms, low rates, hassle-free process."</p>
      <div id="loanimage"></div>
    </div>
    <div class="carloan">
        <img src="002-automobile.png" id="carimg">
        <button class="button button3" style="margin-left: 70px;margin-top: 20px;cursor: pointer;" >Car Loan</button>
                <p style="margin-left: 20px;margin-top: 10px;" >"Drive your dream car with our affordable Car Loans. Quick approvals, low rates, hassle-free process."</p>
      <div id="carimg"></div>
    </div>
    <div class="perloan">
        <img src="003-profits.png" id="perimg">
        <button class="button button3" style="margin-left: 60px;margin-top: 10px;cursor: pointer;" >Personal Loan</button>
        <p style="margin-left: 20px; margin-top: 10px;">"Realize your dreams with our Personal Loans. Fast approvals, flexible terms, and reliable support."</p>
      <div id="perimg"></div>
    </div>
  </div>

  <div class="container">
    <div class="homeloan">
        <img src="006-credit-card.png" id="loanimage"><br>
            <button class="button button3" style="margin-left: 30px;margin-top: 20px;cursor: pointer;" >Small business Loan</button>
            <p style="margin-left: 20px;margin-top: 10px;">"Fuel your small business with our flexible Small Business Loans. Quick approvals, low rates."</p>
      <div id="loanimage"></div>
    </div>
    <div class="carloan">
        <img src="004-ingots.png" id="carimg">
        <button class="button button3" style="margin-left: 40px;margin-top: 20px;cursor: pointer;background-color: rgb(81, 161, 81);" >Emergency Loans</button>
                <p style="margin-left: 20px;margin-top: 10px;" >
                    "Get quick financial support during emergencies with our reliable Emergency Loans. Fast approvals, no delays."</p>
      <div id="carimg"></div>
    </div>
    <div class="perloan">
        <img src="005-mortarboard.png" id="perimg">
        <button class="button button3" style="margin-left: 50px;margin-top: 10px;cursor: pointer;" >Education Loans:</button>
        <p style="margin-left: 20px; margin-top: 10px;">"Realize your dreams with our Personal Loans. Fast approvals, flexible terms, and reliable support.""Invest in your future,"</p>
      <div id="perimg"></div>
    </div>
  </div>

  <div>
    <h1 style="margin-top: 30px;margin-left: 0px;color: rgb(18, 18, 24);padding: 8px;">
      Latest Blog
      </h1>
      <i class="fa-solid fa-bars-progress" style="color: #357e47; margin-top:0px;margin-left: 8px;"></i>
      <h4 style="margin-left: 7px;">
        Unlock possibilities with our diverse loans:<br> Home Loans for your dream abode,<br> Personal Loans for life's needs,<br> and Business Loans for entrepreneurial success.<br> Apply now for financial empowerment!
      </h4>
      <img src="blog-1.jpg" style="height: 250px; width: 250px; border-radius: 20px;" >
       
      <img src="blog-2.jpg" style="height: 250px; width: 250px; border-radius: 20px; margin-left: 20px;" >
       
      <img src="blog-3.jpg" style="height: 250px; width: 250px; border-radius: 20px; margin-left: 20px;" >
      <br> <br> <br>
      <h2>"Transforming Aspirations into Reality  <br> with Personal Loans" </h2>
      <br> 
      <h4>
      "A loan with low interest rates is a valuable financial tool that offers affordable borrowing options.<br> With reduced financial strain, individuals can pursue their goals and aspirations confidently.<br> It paves the way for brighter opportunities and a more secure financial future, promoting responsible and prudent financial decisions."
      </h4>      
  </div>
      <br> 
      <div style="height: 500px; width: 1000px; background-color: rgb(244, 243, 243);">
        <h1 style="padding: 40px;text-decoration:underline #2ca039;"> Customer Stories</h1>
        <div style="height: 220px; width: 470px;background-color:rgb(243, 231, 196); margin-left: 40px;margin-top: 0px;">
         
         <h1> <i class="fa-regular fa-comment" style="color: #36633d; margin-left: 400px; margin-top: 0px;"></i></h1>
         <h4> 
          "Exceptional loan website! Fast and hassle-free application process, competitive interest rates, and excellent customer support. Secured my loan effortlessly. Highly recommended for anyone seeking financial assistance."</h4>
         <img src="user-1.png" style="margin-top: 10px;"> <h4 style="display: inline-block;margin-top: 10px;">ALISHAN</h4>

         <button  style="margin-left: 240px;margin-top: 30px;"><<</button>
        <button >>></button> <img src="review.svg" style="height: 350px; width: 300px;margin-left: 550px;margin-top: -300px;">
        </div>
      </div>
      <br>
    <h1 style="text-decoration: underline #2ca039;">Get In Touch</h1>
     <h3>"Get In Touch: Connecting You to Your Dreams. <br>Realize Your Aspirations with Every Interaction.<br> Your Pathway to Success and Fulfillment." </h3>
    <img src="contact.svg" style="height: 350px; width: 450px; margin-top: -300px;">
    <div style="height: 400px; width: 450px;background-color: rgb(250, 238, 222);display: inline-block;margin-left: 70px;padding: 140px; border-radius: 20px;">
      <h2 style="position: absolute;margin-top: -110px;color: rgb(23, 80, 103);margin-left: -15px;text-decoration: underline;">Send Message</h2>
        <div style="margin-top: -30px;">
          <form action="#" method="post" onsubmit="return showSubmissionAlert()">
          <input type="text" id="username"  name="name" placeholder="Please enter your Name" style="width: 300px;height: 40px; margin-left: -60px;border-radius: 10px;background-color: rgb(200, 241, 241); text-align: center;">
          <br> <br> 
          <input type="text"  name="name" placeholder="Please enter your Email" style="width: 300px;height: 40px; margin-left: -60px;border-radius: 10px;background-color: rgb(200, 241, 241); text-align: center;">
          <br> <br> 
          <input type="text"  name="name" placeholder="Write your Message" style="width: 300px;height: 78px; margin-left: -60px;border-radius: 10px;background-color: rgb(200, 241, 241); text-align: center;"> 
          <br> <br>
          <button style="height: 30px; width: 80px;margin-left: 50px;background-color: lightcyan;">Submit</button>
          </form>
        </div>
    </div>
    <script>
      function showSubmissionAlert(){
        
        var username = document.getElementById('username')
          
        if(username.value ===""){
          alert("please enter your name");
          return false;    
        }else{
        alert("Form submitted successfully!");
        return false;
        }
      }
    </script>
</body>
</html>